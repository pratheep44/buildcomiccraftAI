# ComicCraft — AI Comic Story Creator

ComicCraft is a FastAPI web application that turns a user's story idea into a five-panel comic.

The implementation follows the supplied project specification:

1. Collect story prompt, character name, setting, tone, and art style.
2. Generate a structured five-panel outline with Gemini.
3. Expand the outline into narration and dialogue with Gemini.
4. Generate one illustration per panel with Hugging Face Diffusers / Stable Diffusion.
5. Bind text and images into a panel layout.
6. Export the result as a multi-page PDF.
7. Render the comic in a Jinja2 frontend.

## Architecture

```text
Browser
  |
  v
FastAPI + Jinja2
  |
  +--> Gemini outline model
  |
  +--> Gemini story model
  |
  +--> Diffusers / Stable Diffusion
  |
  +--> Layout builder
  |
  +--> FPDF PDF exporter
  |
  v
static/panels + static/exports
```

## Project structure

```text
ComicCraft/
├── app/
│   ├── __init__.py
│   ├── main.py
│   ├── config.py
│   ├── models.py
│   ├── routes.py
│   └── services/
│       ├── __init__.py
│       ├── comic_service.py
│       ├── exporters.py
│       ├── gemini_client.py
│       ├── gemini_flash.py
│       ├── gemini_pro.py
│       ├── image_generator.py
│       └── layout_builder.py
├── static/
│   ├── css/style.css
│   ├── panels/.gitkeep
│   └── exports/.gitkeep
├── templates/
│   ├── index.html
│   ├── comic_preview.html
│   └── export_success.html
├── tests/
│   ├── __init__.py
│   └── test_layout_builder.py
├── .env.example
├── .gitignore
├── requirements.txt
└── README.md
```

## Requirements

- Python 3.11 recommended.
- A Gemini API key.
- For local Stable Diffusion: a machine with enough RAM/VRAM. CPU generation is supported but can be very slow.
- Windows, macOS, or Linux.

## Windows / VS Code setup

Open the project folder in VS Code.

### 1. Create a virtual environment

PowerShell:

```powershell
py -3.11 -m venv .venv
.\.venv\Scripts\Activate.ps1
```

If PowerShell blocks activation, run:

```powershell
Set-ExecutionPolicy -Scope Process -ExecutionPolicy Bypass
.\.venv\Scripts\Activate.ps1
```

### 2. Install dependencies

```powershell
python -m pip install --upgrade pip
pip install -r requirements.txt
```

PyTorch installation can be hardware-specific. If the normal `pip install -r requirements.txt` does not provide the correct CUDA build for your NVIDIA GPU, install the matching PyTorch build from the official PyTorch installation selector and then run the requirements install again.

### 3. Configure secrets

Copy:

```text
.env.example
```

to:

```text
.env
```

Set:

```env
GEMINI_API_KEY=your_real_key
```

Keep `.env` private and never commit it.

### 4. First smoke test without downloading Stable Diffusion

For a fast backend/UI test, temporarily use:

```env
IMAGE_PROVIDER=placeholder
```

Then start the server:

```powershell
uvicorn app.main:app --reload
```

Open:

```text
http://127.0.0.1:8000
```

The application will still call Gemini, but image generation will create simple placeholder PNGs. This is useful for verifying the entire web/PDF workflow before downloading a large diffusion model.

### 5. Enable real AI images

Change:

```env
IMAGE_PROVIDER=diffusers
```

The first image-generation request downloads the configured Hugging Face model and caches it locally.

The default checkpoint is:

```text
stable-diffusion-v1-5/stable-diffusion-v1-5
```

You can change `HF_MODEL_ID` to another Diffusers-compatible text-to-image checkpoint.

## Run

```powershell
uvicorn app.main:app --reload
```

Web app:

```text
http://127.0.0.1:8000
```

Swagger/OpenAPI:

```text
http://127.0.0.1:8000/docs
```

Health check:

```text
http://127.0.0.1:8000/health
```

## API example

POST JSON to `/generate-comic/json`:

```json
{
  "story_prompt": "A brave fox discovers a hidden moonlit village.",
  "character_name": "Luna",
  "setting": "enchanted forest",
  "tone": "mysterious",
  "art_style": "comic book"
}
```

PowerShell:

```powershell
$body = @{
  story_prompt = "A brave fox discovers a hidden moonlit village."
  character_name = "Luna"
  setting = "enchanted forest"
  tone = "mysterious"
  art_style = "comic book"
} | ConvertTo-Json

Invoke-RestMethod `
  -Uri http://127.0.0.1:8000/generate-comic/json `
  -Method Post `
  -ContentType "application/json" `
  -Body $body
```

## Test image endpoint

Form POST:

```text
POST /test-image
```

Field:

```text
prompt
```

Swagger UI at `/docs` is the easiest way to test it.

## Run automated tests

```powershell
pytest -q
```

The included unit test does not require Gemini or Stable Diffusion because it tests the deterministic layout layer.

## Troubleshooting

### "GEMINI_API_KEY is not configured"

Make sure `.env` exists in the project root and contains a valid key.

### Gemini model not available

Change the model names in `.env`:

```env
GEMINI_OUTLINE_MODEL=gemini-2.5-flash
GEMINI_STORY_MODEL=gemini-2.5-pro
```

The application intentionally keeps these configurable so the AI provider can be changed without editing the application.

### Diffusers is too slow

Use:

```env
IMAGE_PROVIDER=placeholder
```

for development/testing, or use a smaller/faster compatible model and reduce:

```env
IMAGE_STEPS=12
IMAGE_WIDTH=384
IMAGE_HEIGHT=384
```

### CUDA / Torch errors

Check:

```powershell
python -c "import torch; print(torch.__version__); print('CUDA:', torch.cuda.is_available())"
```

If CUDA is false on an NVIDIA system, install the PyTorch build matching your CUDA environment.

### PDF has replacement characters

The included exporter uses FPDF's built-in Latin-1 font for maximum simplicity. If you need full Unicode support for Tamil, Hindi, emoji, or other scripts, add a Unicode TTF font and register it with FPDF before exporting.

## Design notes

The supplied specification names Gemini 1.5 Flash/Pro and `google-generativeai`. This implementation preserves the two-model Flash/Pro separation but uses the current `google-genai` SDK and environment-configurable model IDs.

The supplied specification also identifies Stable Diffusion through Hugging Face Diffusers. The implementation keeps image generation local through Diffusers and loads the pipeline lazily, so simply starting the web server does not immediately download the model.

## Production hardening

Before deploying publicly, add:

- Authentication and authorization.
- Rate limiting.
- Job queues for long-running image generation.
- Persistent database/storage.
- Object storage for generated images/PDFs.
- Request-size and timeout controls.
- Background workers for generation.
- Content moderation and abuse controls.
- Observability and structured logging.
- HTTPS and secure secret management.
