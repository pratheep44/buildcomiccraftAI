from app.models import ComicOutline, ComicStory, PanelOutline, PanelStory
from app.services.layout_builder import build_comic_layout


def test_build_comic_layout():
    outline = ComicOutline(
        panels=[
            PanelOutline(
                panel_number=i,
                title=f"Panel {i}",
                scene_description="Scene",
                image_prompt="Image",
            )
            for i in range(1, 6)
        ]
    )

    story = ComicStory(
        panels=[
            PanelStory(
                panel_number=i,
                title=f"Panel {i}",
                scene_description="Scene",
                caption="Caption",
                narration="Narration",
                dialogue="Dialogue",
                image_prompt="Image",
            )
            for i in range(1, 6)
        ]
    )

    paths = [f"/tmp/panel-{i}.png" for i in range(1, 6)]
    layout = build_comic_layout(story, paths)

    assert len(layout) == 5
    assert layout[0].image_url == "/static/panels/panel-1.png"
    assert layout[-1].panel_number == 5
