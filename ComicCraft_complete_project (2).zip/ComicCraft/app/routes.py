from pathlib import Path

from fastapi import APIRouter, Form, HTTPException, Request
from fastapi.responses import HTMLResponse
from pydantic import ValidationError

from app.config import get_settings
from app.models import PromptRequest
from app.services.comic_service import generate_comic
from app.services.image_generator import generate_image

router = APIRouter()


def _template(request: Request, name: str, context: dict):
    from app.main import templates
    return templates.TemplateResponse(
        request=request,
        name=name,
        context=context,
    )


@router.get("/", response_class=HTMLResponse)
async def home(request: Request):
    return _template(request, "index.html", {"error": None})


@router.post("/generate", response_class=HTMLResponse)
async def generate(
    request: Request,
    story_prompt: str = Form(...),
    character_name: str = Form(...),
    setting: str = Form(...),
    tone: str = Form(...),
    art_style: str = Form(...),
):
    settings = get_settings()
    if len(story_prompt) > settings.max_prompt_length:
        return _template(
            request,
            "index.html",
            {"error": f"Story prompt must be {settings.max_prompt_length} characters or fewer."},
        )

    try:
        prompt_request = PromptRequest(
            story_prompt=story_prompt,
            character_name=character_name,
            setting=setting,
            tone=tone,
            art_style=art_style,
        )
        result = generate_comic(prompt_request)
        return _template(request, "comic_preview.html", {"comic": result})
    except Exception as exc:
        return _template(
            request,
            "index.html",
            {"error": str(exc)},
        )


@router.post("/generate-comic/json")
async def generate_comic_json(payload: PromptRequest):
    try:
        result = generate_comic(payload)
        return result.model_dump()
    except Exception as exc:
        raise HTTPException(status_code=500, detail=str(exc)) from exc


@router.post("/test-image")
async def test_image(prompt: str = Form(...)):
    try:
        path = generate_image(prompt, panel_number=0)
        return {
            "image_url": f"/static/panels/{Path(path).name}",
            "path": path,
        }
    except Exception as exc:
        raise HTTPException(status_code=500, detail=str(exc)) from exc


@router.get("/export-success", response_class=HTMLResponse)
async def export_success(request: Request, pdf_url: str = ""):
    return _template(
        request,
        "export_success.html",
        {"pdf_url": pdf_url},
    )
