from pathlib import Path

from app.models import ComicPanel, ComicStory


def build_comic_layout(story: ComicStory, image_paths: list[str]) -> list[ComicPanel]:
    if len(story.panels) != len(image_paths):
        raise ValueError("Every story panel must have a corresponding image.")

    layout: list[ComicPanel] = []
    for panel, image_path in zip(story.panels, image_paths):
        filename = Path(image_path).name
        layout.append(
            ComicPanel(
                panel_number=panel.panel_number,
                title=panel.title,
                image_url=f"/static/panels/{filename}",
                scene_description=panel.scene_description,
                caption=panel.caption,
                narration=panel.narration,
                dialogue=panel.dialogue,
                image_prompt=panel.image_prompt,
            )
        )
    return layout
