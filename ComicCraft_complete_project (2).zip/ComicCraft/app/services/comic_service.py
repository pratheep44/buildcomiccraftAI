from app.models import ComicResult, PromptRequest
from app.services.exporters import save_pdf
from app.services.gemini_flash import generate_outline
from app.services.gemini_pro import generate_story
from app.services.image_generator import generate_image
from app.services.layout_builder import build_comic_layout


def generate_comic(request: PromptRequest) -> ComicResult:
    outline = generate_outline(request)
    story = generate_story(request, outline)

    image_paths = [
        generate_image(panel.image_prompt, panel.panel_number)
        for panel in story.panels
    ]

    layout = build_comic_layout(story, image_paths)
    pdf_path = save_pdf(
        title=f"{request.character_name}'s Comic",
        panels=layout,
    )

    from pathlib import Path
    pdf_url = f"/static/exports/{Path(pdf_path).name}"

    return ComicResult(
        title=f"{request.character_name}'s Comic",
        panels=layout,
        pdf_url=pdf_url,
    )
