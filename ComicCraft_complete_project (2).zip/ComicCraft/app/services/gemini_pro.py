from google.genai import types

from app.config import get_settings
from app.models import ComicOutline, ComicStory, PromptRequest
from app.services.gemini_client import get_gemini_client


def generate_story(request: PromptRequest, outline: ComicOutline) -> ComicStory:
    settings = get_settings()
    client = get_gemini_client()

    outline_text = outline.model_dump_json(indent=2)

    prompt = f"""
Expand this 5-panel comic outline into polished comic writing.

User story idea: {request.story_prompt}
Main character: {request.character_name}
Setting: {request.setting}
Tone: {request.tone}
Art style: {request.art_style}

Outline:
{outline_text}

Requirements:
- Return exactly 5 panels with the same panel numbers and titles.
- Preserve continuity between panels.
- Keep narration concise enough for a comic page.
- caption should be a short ambient/action caption.
- dialogue should contain the main character's spoken line(s), or be an empty string if no dialogue is needed.
- narration should explain action/emotion without repeating the dialogue.
- scene_description should remain visual and useful to an illustrator.
- image_prompt should be self-contained and preserve the character, setting, action, composition, lighting, and requested art style.
- Do not request readable text, speech bubbles, captions, logos, or watermarks in the image.
"""

    response = client.models.generate_content(
        model=settings.gemini_story_model,
        contents=prompt,
        config=types.GenerateContentConfig(
            response_mime_type="application/json",
            response_schema=ComicStory,
            temperature=0.85,
        ),
    )

    if not response.parsed:
        raise RuntimeError("Gemini returned no structured comic story.")

    return response.parsed
