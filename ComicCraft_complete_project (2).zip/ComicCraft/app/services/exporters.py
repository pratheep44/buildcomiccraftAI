from datetime import datetime
from pathlib import Path

from fpdf import FPDF

from app.config import get_settings
from app.models import ComicPanel


def _clean_pdf_text(value: str) -> str:
    # Built-in FPDF fonts are Latin-1 based. Replace unsupported characters safely.
    return value.encode("latin-1", errors="replace").decode("latin-1")


def save_pdf(title: str, panels: list[ComicPanel]) -> str:
    settings = get_settings()
    timestamp = datetime.now().strftime("%Y%m%d_%H%M%S")
    output_path = settings.exports_dir / f"comiccraft_{timestamp}.pdf"

    pdf = FPDF(orientation="P", unit="mm", format="A4")
    pdf.set_auto_page_break(auto=True, margin=15)

    for panel in panels:
        pdf.add_page()
        pdf.set_font("Arial", "B", 18)
        pdf.multi_cell(0, 10, _clean_pdf_text(f"Panel {panel.panel_number}: {panel.title}"))

        image_file = settings.output_dir / panel.image_url.removeprefix("/static/")
        if image_file.exists():
            pdf.image(str(image_file), x=15, y=38, w=180)

        pdf.ln(95)
        pdf.set_font("Arial", "I", 11)
        pdf.multi_cell(0, 7, _clean_pdf_text(panel.scene_description))

        pdf.ln(3)
        pdf.set_font("Arial", "B", 11)
        pdf.multi_cell(0, 7, _clean_pdf_text(f"Caption: {panel.caption}"))

        pdf.ln(2)
        pdf.set_font("Arial", "", 11)
        pdf.multi_cell(0, 7, _clean_pdf_text(f"Narration: {panel.narration}"))

        if panel.dialogue.strip():
            pdf.ln(2)
            pdf.set_font("Arial", "B", 11)
            pdf.multi_cell(0, 7, _clean_pdf_text(f"Dialogue: {panel.dialogue}"))

    pdf.output(str(output_path))
    return str(output_path)
