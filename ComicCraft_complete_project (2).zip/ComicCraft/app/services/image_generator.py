import hashlib
import threading
from pathlib import Path

from PIL import Image, ImageDraw, ImageFont

from app.config import get_settings

_pipeline = None
_pipeline_lock = threading.Lock()


def _safe_name(value: str, max_length: int = 60) -> str:
    cleaned = "".join(ch.lower() if ch.isalnum() else "-" for ch in value)
    cleaned = "-".join(part for part in cleaned.split("-") if part)
    return cleaned[:max_length] or "panel"


def _placeholder_image(prompt: str, output_path: Path) -> None:
    settings = get_settings()
    image = Image.new("RGB", (settings.image_width, settings.image_height), "white")
    draw = ImageDraw.Draw(image)
    title = "ComicCraft"
    body = prompt[:450]

    try:
        font = ImageFont.truetype("arial.ttf", 28)
        body_font = ImageFont.truetype("arial.ttf", 18)
    except OSError:
        font = ImageFont.load_default()
        body_font = ImageFont.load_default()

    draw.text((24, 24), title, fill="black", font=font)
    draw.text(
        (24, 90),
        "Placeholder image mode",
        fill="black",
        font=body_font,
    )
    draw.multiline_text(
        (24, 135),
        body,
        fill="black",
        font=body_font,
        spacing=8,
    )
    image.save(output_path, format="PNG")


def _get_pipeline():
    global _pipeline
    if _pipeline is not None:
        return _pipeline

    with _pipeline_lock:
        if _pipeline is not None:
            return _pipeline

        import torch
        from diffusers import DiffusionPipeline

        settings = get_settings()
        dtype = torch.float16 if torch.cuda.is_available() else torch.float32

        kwargs = {"torch_dtype": dtype}
        if settings.hf_api_key:
            kwargs["token"] = settings.hf_api_key

        _pipeline = DiffusionPipeline.from_pretrained(
            settings.hf_model_id,
            **kwargs,
        )
        _pipeline = _pipeline.to("cuda" if torch.cuda.is_available() else "cpu")
        return _pipeline


def generate_image(prompt: str, panel_number: int) -> str:
    settings = get_settings()
    filename = f"panel-{panel_number}-{_safe_name(prompt)}.png"
    output_path = settings.panels_dir / filename

    if settings.image_provider.lower() == "placeholder":
        _placeholder_image(prompt, output_path)
        return str(output_path)

    pipeline = _get_pipeline()

    import torch

    generator = None
    if settings.image_seed is not None:
        device = "cuda" if torch.cuda.is_available() else "cpu"
        generator = torch.Generator(device=device).manual_seed(settings.image_seed + panel_number)

    result = pipeline(
        prompt=prompt,
        negative_prompt=(
            "text, words, letters, subtitles, speech bubbles, captions, logo, "
            "watermark, signature, distorted anatomy, blurry, low quality"
        ),
        width=settings.image_width,
        height=settings.image_height,
        num_inference_steps=settings.image_steps,
        guidance_scale=settings.image_guidance_scale,
        generator=generator,
    )

    image = result.images[0]
    image.save(output_path, format="PNG")
    return str(output_path)
