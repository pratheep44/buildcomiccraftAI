from google.genai import types

from app.config import get_settings
from app.models import ComicOutline, PromptRequest
from app.services.gemini_client import get_gemini_client


def generate_outline(request: PromptRequest) -> ComicOutline:
    settings = get_settings()
    client = get_gemini_client()

    prompt = f"""
Create a coherent 5-panel comic outline.

User story idea: {request.story_prompt}
Main character: {request.character_name}
Setting: {request.setting}
Tone: {request.tone}
Art style: {request.art_style}

Requirements:
- Exactly 5 panels, numbered 1 through 5.
- Establish the situation early, develop a clear middle, and give the fifth panel a satisfying ending.
- Keep the main character visually consistent across all panels.
- scene_description should describe visible action, environment, composition, lighting, and mood.
- image_prompt must be a self-contained prompt for a text-to-image model.
- Do not put dialogue in image_prompt.
- Avoid speech bubbles, captions, watermarks, logos, signatures, or readable text inside generated artwork.
"""

    response = client.models.generate_content(
        model=settings.gemini_outline_model,
        contents=prompt,
        config=types.GenerateContentConfig(
            response_mime_type="application/json",
            response_schema=ComicOutline,
            temperature=0.9,
        ),
    )

    if not response.parsed:
        raise RuntimeError("Gemini returned no structured comic outline.")

    return response.parsed
